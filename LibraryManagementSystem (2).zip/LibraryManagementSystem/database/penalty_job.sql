-- Calculate and upsert penalties for overdue borrowed books
-- Run daily via scheduler or manually
USE library_management;

INSERT INTO penalties (borrow_id, user_id, days_overdue, penalty_amount, paid)
SELECT b.borrow_id, b.user_id,
       GREATEST(DATEDIFF(CURDATE(), b.due_date),0) AS days_overdue,
       GREATEST(DATEDIFF(CURDATE(), b.due_date),0) * 10.0 AS penalty_amount,
       FALSE
FROM borrowed_books b
LEFT JOIN penalties p ON p.borrow_id = b.borrow_id
WHERE b.status = 'BORROWED' AND CURDATE() > b.due_date AND p.borrow_id IS NULL;
