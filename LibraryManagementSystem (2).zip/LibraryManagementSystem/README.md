# Library Management System (Java Swing + JDBC + MySQL/MariaDB)

A desktop Library app with Admin/User roles, borrowing with penalties, purchasing, and a modern UI.

## Prerequisites
- Java JDK 8+ (javac/java on PATH)
- MySQL or MariaDB server and client (mysql CLI)
- MySQL Connector/J jar in `lib/` (example: `lib/mysql-connector-j-8.4.0.jar`)
  - PowerShell (download to `lib/`):
    - `Invoke-WebRequest -Uri https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.4.0/mysql-connector-j-8.4.0.jar -OutFile lib/mysql-connector-j-8.4.0.jar -UseBasicParsing`

## Database Setup (Windows PowerShell)
### Option A: MariaDB quick start (recommended)
1. Install MariaDB:
   - `winget install -e --id MariaDB.Server --accept-package-agreements --accept-source-agreements`
2. Start server (no Admin required):
   - `Start-Process -FilePath 'C:\\Program Files\\MariaDB 12.0\\bin\\mysqld.exe' -ArgumentList '--defaults-file="C:\\Program Files\\MariaDB 12.0\\data\\my.ini"' -WindowStyle Hidden`
3. Create schema and seed data (300+ books):
   - `Get-Content -Raw database/schema.sql | & 'C:\\Program Files\\MariaDB 12.0\\bin\\mysql.exe' -h 127.0.0.1 -u root`
4. (Optional) Create purchases table and penalty job:
   - `Get-Content -Raw database/purchases.sql | & 'C:\\Program Files\\MariaDB 12.0\\bin\\mysql.exe' -h 127.0.0.1 -u root`
   - `Get-Content -Raw database/penalty_job.sql | & 'C:\\Program Files\\MariaDB 12.0\\bin\\mysql.exe' -h 127.0.0.1 -u root`

### Option B: MySQL
- Import using mysql CLI (PowerShell-friendly piping):
  - `Get-Content -Raw database/schema.sql | mysql -h 127.0.0.1 -u root -p`
  - Also run: `database/purchases.sql` and optionally `database/penalty_job.sql` the same way.

## Configure DB connection
- Edit `src/com/library/util/DatabaseConnection.java`:
  - Set `USER` and `PASSWORD` to your DB credentials.
  - Default URL is `jdbc:mysql://127.0.0.1:3306/library_management?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&connectTimeout=5000&socketTimeout=5000`.

## Build and Run (PowerShell)
- Compile all sources to `out/`:
  - `javac -cp ".;lib/mysql-connector-j-8.4.0.jar" -d out (Get-ChildItem -Recurse src\*.java | ForEach-Object { $_.FullName })`
- Run the app:
  - `java -cp ".;out;lib/mysql-connector-j-8.4.0.jar" com.library.gui.LibraryManagementSystem`

## Features
- Auth: Sign In / Sign Up (modern UI)
- User dashboard:
  - Search and borrow (10/20/30 days), live availability
  - "My Borrowed Books" with Days Held, Overdue Days, and live Penalty (Rs 10/day)
  - Purchase Selected (decrements stock and records purchase)
- Admin dashboard:
  - Add/Delete books, Update price
  - View Purchases (user, book, price, time)
  - View Borrows (user, book, dates, status, overdue days)
- Penalties:
  - Applied on return if overdue; optional daily job for still-borrowed items

## Default Accounts
- Admin: `admin` / `admin123`
- User: `user1` / `user123`

## Troubleshooting
- Communication link failure:
  - Ensure DB is running and reachable: `Test-NetConnection 127.0.0.1 -Port 3306`
  - Verify `DatabaseConnection.USER`/`PASSWORD`, firewall, and JDBC URL host/port
- Access denied for user 'root':
  - Update credentials in `DatabaseConnection.java` or create a dedicated app user in DB
- mysql.exe not found:
  - Use the full path (e.g., `C:\\Program Files\\MariaDB 12.0\\bin\\mysql.exe`) or add to PATH
