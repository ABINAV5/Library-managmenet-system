package com.library.dao;

import com.library.model.BorrowedBook;
import com.library.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;

public class BorrowDAO {
    public int borrowBook(int userId, int bookId, int durationDays) throws SQLException {
        // durationDays allowed: 10, 20, 30
        if (durationDays != 10 && durationDays != 20 && durationDays != 30) {
            throw new IllegalArgumentException("Invalid duration");
        }
        String insertBorrow = "INSERT INTO borrowed_books (user_id, book_id, borrow_date, due_date, borrow_duration, status) VALUES (?,?,?,?,?,?)";
        String decAvail = "UPDATE books SET available_quantity = available_quantity - 1 WHERE book_id=? AND available_quantity > 0";
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Decrement stock first
                try (PreparedStatement ps = conn.prepareStatement(decAvail)) {
                    ps.setInt(1, bookId);
                    int updated = ps.executeUpdate();
                    if (updated == 0) {
                        conn.rollback();
                        throw new SQLException("Book not available");
                    }
                }
                LocalDate borrowDate = LocalDate.now();
                LocalDate dueDate = borrowDate.plusDays(durationDays);
                try (PreparedStatement ps = conn.prepareStatement(insertBorrow, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, userId);
                    ps.setInt(2, bookId);
                    ps.setDate(3, Date.valueOf(borrowDate));
                    ps.setDate(4, Date.valueOf(dueDate));
                    ps.setInt(5, durationDays);
                    ps.setString(6, "BORROWED");
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) {
                            int borrowId = rs.getInt(1);
                            conn.commit();
                            return borrowId;
                        }
                    }
                }
                conn.rollback();
                throw new SQLException("Failed to create borrow record");
            } catch (Exception ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public boolean returnBook(int borrowId) throws SQLException {
        String getBorrow = "SELECT book_id, due_date FROM borrowed_books WHERE borrow_id=? AND status='BORROWED'";
        String updateBorrow = "UPDATE borrowed_books SET return_date=?, status=? WHERE borrow_id=?";
        String incAvail = "UPDATE books SET available_quantity = available_quantity + 1 WHERE book_id=? AND available_quantity < quantity";
        String insertPenalty = "INSERT INTO penalties (borrow_id, user_id, days_overdue, penalty_amount, paid) SELECT b.borrow_id, b.user_id, GREATEST(DATEDIFF(CURDATE(), b.due_date),0) as days_overdue, GREATEST(DATEDIFF(CURDATE(), b.due_date),0) * 10.0 as penalty_amount, FALSE FROM borrowed_books b WHERE b.borrow_id=? AND CURDATE() > b.due_date";
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                int bookId = -1;
                try (PreparedStatement ps = conn.prepareStatement(getBorrow)) {
                    ps.setInt(1, borrowId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            bookId = rs.getInt("book_id");
                        } else {
                            conn.rollback();
                            return false;
                        }
                    }
                }
                try (PreparedStatement ps = conn.prepareStatement(updateBorrow)) {
                    ps.setDate(1, new Date(System.currentTimeMillis()));
                    ps.setString(2, "RETURNED");
                    ps.setInt(3, borrowId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = conn.prepareStatement(incAvail)) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = conn.prepareStatement(insertPenalty)) {
                    ps.setInt(1, borrowId);
                    ps.executeUpdate();
                }
                conn.commit();
                return true;
            } catch (Exception ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public java.util.List<com.library.model.BorrowStatus> getActiveBorrowsByUser(int userId) throws SQLException {
        String sql = "SELECT b.borrow_id, b.book_id, bk.title, b.borrow_date, b.due_date, " +
                "DATEDIFF(CURDATE(), b.borrow_date) AS days_held, " +
                "GREATEST(DATEDIFF(CURDATE(), b.due_date),0) AS days_overdue, " +
                "GREATEST(DATEDIFF(CURDATE(), b.due_date),0) * 10.0 AS penalty, " +
                "CASE WHEN CURDATE() > b.due_date THEN 'OVERDUE' ELSE 'BORROWED' END AS computed_status " +
                "FROM borrowed_books b JOIN books bk ON b.book_id=bk.book_id " +
                "WHERE b.user_id=? AND b.status IN ('BORROWED','OVERDUE') ORDER BY b.borrow_date DESC";
        java.util.List<com.library.model.BorrowStatus> list = new java.util.ArrayList<>();
        try (java.sql.Connection conn = com.library.util.DatabaseConnection.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    com.library.model.BorrowStatus s = new com.library.model.BorrowStatus();
                    s.setBorrowId(rs.getInt("borrow_id"));
                    s.setBookId(rs.getInt("book_id"));
                    s.setTitle(rs.getString("title"));
                    java.sql.Date bd = rs.getDate("borrow_date");
                    java.sql.Date dd = rs.getDate("due_date");
                    s.setBorrowDate(bd == null ? null : bd.toLocalDate());
                    s.setDueDate(dd == null ? null : dd.toLocalDate());
                    s.setDaysHeld(rs.getInt("days_held"));
                    s.setDaysOverdue(rs.getInt("days_overdue"));
                    s.setPenaltyAmount(rs.getDouble("penalty"));
                    s.setStatus(rs.getString("computed_status"));
                    list.add(s);
                }
            }
        }
        return list;
    }

    public java.util.List<com.library.model.BorrowAdminRecord> listBorrows(int limit) throws SQLException {
        String sql = "SELECT b.borrow_id, b.user_id, u.username, u.full_name, b.book_id, bk.title, b.borrow_date, b.due_date, b.return_date, b.status, " +
                "GREATEST(DATEDIFF(CURDATE(), b.due_date),0) AS overdue_days " +
                "FROM borrowed_books b JOIN users u ON b.user_id=u.user_id JOIN books bk ON b.book_id=bk.book_id " +
                "ORDER BY b.borrow_date DESC LIMIT ?";
        java.util.List<com.library.model.BorrowAdminRecord> list = new java.util.ArrayList<>();
        try (java.sql.Connection conn = com.library.util.DatabaseConnection.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    com.library.model.BorrowAdminRecord r = new com.library.model.BorrowAdminRecord();
                    r.setBorrowId(rs.getInt("borrow_id"));
                    r.setUserId(rs.getInt("user_id"));
                    r.setUsername(rs.getString("username"));
                    r.setFullName(rs.getString("full_name"));
                    r.setBookId(rs.getInt("book_id"));
                    r.setTitle(rs.getString("title"));
                    java.sql.Date bd = rs.getDate("borrow_date");
                    java.sql.Date dd = rs.getDate("due_date");
                    java.sql.Date rd = rs.getDate("return_date");
                    r.setBorrowDate(bd == null ? null : bd.toLocalDate());
                    r.setDueDate(dd == null ? null : dd.toLocalDate());
                    r.setReturnDate(rd == null ? null : rd.toLocalDate());
                    r.setStatus(rs.getString("status"));
                    r.setOverdueDays(rs.getInt("overdue_days"));
                    list.add(r);
                }
            }
        }
        return list;
    }
}
