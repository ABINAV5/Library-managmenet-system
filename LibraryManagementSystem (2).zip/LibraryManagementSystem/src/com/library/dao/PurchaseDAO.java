package com.library.dao;

import com.library.util.DatabaseConnection;

import java.sql.*;

public class PurchaseDAO {
    public int purchaseBook(int userId, int bookId) throws SQLException {
        String selectForUpdate = "SELECT price, available_quantity, quantity FROM books WHERE book_id=? FOR UPDATE";
        String updateBook = "UPDATE books SET available_quantity = available_quantity - 1, quantity = quantity - 1 WHERE book_id=? AND available_quantity > 0 AND quantity > 0";
        String insertPurchase = "INSERT INTO purchases (user_id, book_id, price) VALUES (?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                double price;
                try (PreparedStatement ps = conn.prepareStatement(selectForUpdate)) {
                    ps.setInt(1, bookId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            conn.rollback();
                            throw new SQLException("Book not found");
                        }
                        int avail = rs.getInt("available_quantity");
                        int qty = rs.getInt("quantity");
                        if (avail <= 0 || qty <= 0) {
                            conn.rollback();
                            throw new SQLException("Book out of stock");
                        }
                        price = rs.getDouble("price");
                    }
                }
                try (PreparedStatement ps = conn.prepareStatement(updateBook)) {
                    ps.setInt(1, bookId);
                    int ok = ps.executeUpdate();
                    if (ok == 0) {
                        conn.rollback();
                        throw new SQLException("Failed to decrement stock");
                    }
                }
                try (PreparedStatement ps = conn.prepareStatement(insertPurchase, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, userId);
                    ps.setInt(2, bookId);
                    ps.setDouble(3, price);
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) {
                            int purchaseId = rs.getInt(1);
                            conn.commit();
                            return purchaseId;
                        }
                    }
                }
                conn.rollback();
                throw new SQLException("Failed to create purchase");
            } catch (Exception e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public java.util.List<com.library.model.PurchaseRecord> listPurchases(int limit) throws SQLException {
        String sql = "SELECT p.purchase_id, p.user_id, u.username, u.full_name, p.book_id, b.title, p.price, p.purchase_date " +
                "FROM purchases p JOIN users u ON p.user_id=u.user_id JOIN books b ON p.book_id=b.book_id " +
                "ORDER BY p.purchase_date DESC LIMIT ?";
        java.util.List<com.library.model.PurchaseRecord> list = new java.util.ArrayList<>();
        try (java.sql.Connection conn = com.library.util.DatabaseConnection.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    com.library.model.PurchaseRecord r = new com.library.model.PurchaseRecord();
                    r.setPurchaseId(rs.getInt("purchase_id"));
                    r.setUserId(rs.getInt("user_id"));
                    r.setUsername(rs.getString("username"));
                    r.setFullName(rs.getString("full_name"));
                    r.setBookId(rs.getInt("book_id"));
                    r.setTitle(rs.getString("title"));
                    r.setPrice(rs.getDouble("price"));
                    java.sql.Timestamp ts = rs.getTimestamp("purchase_date");
                    r.setPurchaseDate(ts == null ? null : ts.toLocalDateTime());
                    list.add(r);
                }
            }
        }
        return list;
    }
}
