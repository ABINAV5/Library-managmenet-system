package com.library.gui;

import com.library.dao.UserDAO;
import com.library.model.User;
import com.library.util.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;

public class AuthFrame extends JFrame {
    private final UserDAO userDAO = new UserDAO();

    public AuthFrame() {
        setTitle("Library - Sign In / Sign Up");
        setSize(520, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Sign In", buildSignInPanel());
        tabs.addTab("Sign Up", buildSignUpPanel());
        JPanel content = new JPanel(new BorderLayout());
        content.add(UIUtils.makeHeaderPanel("Library", "Sign in or create a new account"), BorderLayout.NORTH);
        content.add(tabs, BorderLayout.CENTER);
        add(content);
    }

    private JPanel buildSignInPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Welcome Back");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel();
        GroupLayout gl = new GroupLayout(form);
        form.setLayout(gl);
        gl.setAutoCreateGaps(true);
        gl.setAutoCreateContainerGaps(true);

        JLabel userLbl = new JLabel("Username");
        JTextField userTxt = new JTextField(20);
        JLabel passLbl = new JLabel("Password");
        JPasswordField passTxt = new JPasswordField(20);
        JCheckBox showPass = new JCheckBox("Show password");
        showPass.addActionListener(e -> passTxt.setEchoChar(showPass.isSelected() ? (char)0 : '\u2022'));

        JButton loginBtn = new JButton("Sign In");
        UIUtils.stylePrimary(loginBtn);
        loginBtn.addActionListener(e -> doLogin(userTxt.getText().trim(), new String(passTxt.getPassword())));

        gl.setHorizontalGroup(
            gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(gl.createSequentialGroup()
                    .addGroup(gl.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(userLbl)
                        .addComponent(passLbl))
                    .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(userTxt)
                        .addComponent(passTxt)
                        .addComponent(showPass)))
                .addComponent(loginBtn, GroupLayout.Alignment.TRAILING)
        );
        gl.setVerticalGroup(
            gl.createSequentialGroup()
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(userLbl).addComponent(userTxt))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(passLbl).addComponent(passTxt))
                .addComponent(showPass)
                .addGap(20)
                .addComponent(loginBtn)
        );

        panel.add(form, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildSignUpPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Create Your Account");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel();
        GroupLayout gl = new GroupLayout(form);
        form.setLayout(gl);
        gl.setAutoCreateGaps(true);
        gl.setAutoCreateContainerGaps(true);

        JLabel nameLbl = new JLabel("Full Name");
        JTextField nameTxt = new JTextField(20);
        JLabel usernameLbl = new JLabel("Username");
        JTextField usernameTxt = new JTextField(20);
        JLabel emailLbl = new JLabel("Email");
        JTextField emailTxt = new JTextField(20);
        JLabel phoneLbl = new JLabel("Phone");
        JTextField phoneTxt = new JTextField(20);
        JLabel passLbl = new JLabel("Password");
        JPasswordField passTxt = new JPasswordField(20);
        JLabel confirmLbl = new JLabel("Confirm Password");
        JPasswordField confirmTxt = new JPasswordField(20);
        JCheckBox showPass = new JCheckBox("Show passwords");
        showPass.addActionListener(e -> {
            char echo = showPass.isSelected() ? (char)0 : '\u2022';
            passTxt.setEchoChar(echo);
            confirmTxt.setEchoChar(echo);
        });

        JButton signupBtn = new JButton("Create Account");
        UIUtils.styleSuccess(signupBtn);
        signupBtn.addActionListener(e -> doSignup(nameTxt.getText().trim(), usernameTxt.getText().trim(),
                emailTxt.getText().trim(), phoneTxt.getText().trim(), new String(passTxt.getPassword()), new String(confirmTxt.getPassword())));

        gl.setHorizontalGroup(
            gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(gl.createSequentialGroup()
                    .addGroup(gl.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(nameLbl)
                        .addComponent(usernameLbl)
                        .addComponent(emailLbl)
                        .addComponent(phoneLbl)
                        .addComponent(passLbl)
                        .addComponent(confirmLbl))
                    .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(nameTxt)
                        .addComponent(usernameTxt)
                        .addComponent(emailTxt)
                        .addComponent(phoneTxt)
                        .addComponent(passTxt)
                        .addComponent(confirmTxt)
                        .addComponent(showPass)))
                .addComponent(signupBtn, GroupLayout.Alignment.TRAILING)
        );
        gl.setVerticalGroup(
            gl.createSequentialGroup()
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(nameLbl).addComponent(nameTxt))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(usernameLbl).addComponent(usernameTxt))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(emailLbl).addComponent(emailTxt))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(phoneLbl).addComponent(phoneTxt))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(passLbl).addComponent(passTxt))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(confirmLbl).addComponent(confirmTxt))
                .addComponent(showPass)
                .addGap(20)
                .addComponent(signupBtn)
        );

        panel.add(form, BorderLayout.CENTER);
        return panel;
    }

    private void doLogin(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter username and password");
            return;
        }
        try {
            User user = userDAO.authenticate(username, password);
            if (user == null) {
                JOptionPane.showMessageDialog(this, "Invalid credentials");
                return;
            }
            if ("ADMIN".equalsIgnoreCase(user.getRole())) {
                SwingUtilities.invokeLater(() -> new AdminDashboard().setVisible(true));
            } else {
                User u = user;
                SwingUtilities.invokeLater(() -> new UserDashboard(u).setVisible(true));
            }
            // Close login window after successful navigation
            this.dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Login error: " + ex.getMessage());
        }
    }

    private void doSignup(String fullName, String username, String email, String phone, String password, String confirm) {
        if (fullName.isEmpty() || username.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill required fields");
            return;
        }
        if (!password.equals(confirm)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match");
            return;
        }
        try {
            if (userDAO.usernameExists(username)) {
                JOptionPane.showMessageDialog(this, "Username already taken");
                return;
            }
            int id = userDAO.createUser(username, password, fullName, email, phone);
            if (id > 0) {
                JOptionPane.showMessageDialog(this, "Account created. Signing you in...");
                doLogin(username, password);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to create account");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Signup error: " + ex.getMessage());
        }
    }
}
