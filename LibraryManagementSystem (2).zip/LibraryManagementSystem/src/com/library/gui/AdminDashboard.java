package com.library.gui;

import com.library.dao.BookDAO;
import com.library.dao.BorrowDAO;
import com.library.dao.PurchaseDAO;
import com.library.model.Book;
import com.library.util.UIUtils;
import com.library.gui.AuthFrame;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.util.List;

public class AdminDashboard extends JFrame {
    private BookDAO bookDAO = new BookDAO();
    private BorrowDAO borrowDAO = new BorrowDAO();
    private PurchaseDAO purchaseDAO = new PurchaseDAO();
    private JTable table;
    private DefaultTableModel model;
    private JTextField isbnField, titleField, authorField, categoryField, publisherField, yearField, priceField, qtyField;
    private JTextField priceUpdateField, searchField;

    public AdminDashboard() {
        setTitle("Library Admin Dashboard");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel header = UIUtils.makeHeaderPanel("Admin Dashboard", "Manage inventory, prices, and view activity");

        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel searchPanel = new JPanel();
        searchField = new JTextField(30);
        JButton searchBtn = new JButton("Search");
        UIUtils.styleSecondary(searchBtn);
        searchBtn.addActionListener(e -> loadBooks(searchField.getText().trim()));
        JButton refreshBtn = new JButton("Refresh");
        UIUtils.styleSecondary(refreshBtn);
        refreshBtn.addActionListener(e -> loadBooks(""));
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);
        topPanel.add(searchPanel, BorderLayout.WEST);

        JPanel actionsPanel = new JPanel();
        JButton viewPurchasesBtn = new JButton("View Purchases");
        viewPurchasesBtn.addActionListener(e -> showPurchasesDialog());
        JButton viewBorrowsBtn = new JButton("View Borrows");
        viewBorrowsBtn.addActionListener(e -> showBorrowsDialog());
        JButton logoutBtn = new JButton("Logout");
        UIUtils.styleDanger(logoutBtn);
        logoutBtn.addActionListener(e -> {
            this.dispose();
            SwingUtilities.invokeLater(() -> new AuthFrame().setVisible(true));
        });
        actionsPanel.add(viewPurchasesBtn);
        actionsPanel.add(viewBorrowsBtn);
        actionsPanel.add(logoutBtn);
        topPanel.add(actionsPanel, BorderLayout.EAST);

        table = new JTable();
        model = new DefaultTableModel(new Object[]{"ID","ISBN","Title","Author","Category","Publisher","Year","Price","Qty","Available"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table.setModel(model);
        UIUtils.applyTableStyles(table);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel formPanel = new JPanel(new GridLayout(3, 8, 5, 5));
        isbnField = new JTextField();
        titleField = new JTextField();
        authorField = new JTextField();
        categoryField = new JTextField();
        publisherField = new JTextField();
        yearField = new JTextField();
        priceField = new JTextField();
        qtyField = new JTextField();

        formPanel.add(new JLabel("ISBN"));
        formPanel.add(isbnField);
        formPanel.add(new JLabel("Title"));
        formPanel.add(titleField);
        formPanel.add(new JLabel("Author"));
        formPanel.add(authorField);
        formPanel.add(new JLabel("Category"));
        formPanel.add(categoryField);
        formPanel.add(new JLabel("Publisher"));
        formPanel.add(publisherField);
        formPanel.add(new JLabel("Year"));
        formPanel.add(yearField);
        formPanel.add(new JLabel("Price"));
        formPanel.add(priceField);
        formPanel.add(new JLabel("Quantity"));
        formPanel.add(qtyField);

        JButton addBtn = new JButton("Add Book");
        UIUtils.styleSuccess(addBtn);
        addBtn.addActionListener(this::handleAddBook);
        JButton deleteBtn = new JButton("Delete Selected");
        UIUtils.styleDanger(deleteBtn);
        deleteBtn.addActionListener(this::handleDeleteBook);

        JPanel bottomPanel = new JPanel();
        priceUpdateField = new JTextField(10);
        JButton updatePriceBtn = new JButton("Update Price");
        UIUtils.stylePrimary(updatePriceBtn);
        updatePriceBtn.addActionListener(this::handleUpdatePrice);
        bottomPanel.add(new JLabel("New Price:"));
        bottomPanel.add(priceUpdateField);
        bottomPanel.add(updatePriceBtn);
        bottomPanel.add(addBtn);
        bottomPanel.add(deleteBtn);

        JPanel northContainer = new JPanel(new BorderLayout());
        northContainer.add(header, BorderLayout.NORTH);
        northContainer.add(topPanel, BorderLayout.CENTER);
        add(northContainer, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        JPanel southContainer = new JPanel(new BorderLayout());
        southContainer.add(formPanel, BorderLayout.CENTER);
        southContainer.add(bottomPanel, BorderLayout.SOUTH);
        add(southContainer, BorderLayout.SOUTH);

        loadBooks("");
    }

    private void loadBooks(String keyword) {
        try {
            model.setRowCount(0);
            List<Book> books = keyword == null || keyword.isEmpty() ? bookDAO.getAllBooks() : bookDAO.searchBooks(keyword);
            for (Book b : books) {
                model.addRow(new Object[]{b.getBookId(), b.getIsbn(), b.getTitle(), b.getAuthor(), b.getCategory(), b.getPublisher(), b.getPublicationYear(), b.getPrice(), b.getQuantity(), b.getAvailableQuantity()});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading books: " + ex.getMessage());
        }
    }

    private void handleAddBook(ActionEvent e) {
        try {
            Book b = new Book();
            b.setIsbn(isbnField.getText().trim());
            b.setTitle(titleField.getText().trim());
            b.setAuthor(authorField.getText().trim());
            b.setCategory(categoryField.getText().trim());
            b.setPublisher(publisherField.getText().trim());
            b.setPublicationYear(Integer.parseInt(yearField.getText().trim()));
            b.setPrice(Double.parseDouble(priceField.getText().trim()));
            int qty = Integer.parseInt(qtyField.getText().trim());
            b.setQuantity(qty);
            b.setAvailableQuantity(qty);
            int id = bookDAO.addBook(b);
            if (id > 0) {
                JOptionPane.showMessageDialog(this, "Book added with ID: " + id);
                loadBooks("");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to add: " + ex.getMessage());
        }
    }

    private void handleDeleteBook(ActionEvent e) {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a row first"); return; }
        int bookId = (int) model.getValueAt(row, 0);
        try {
            if (bookDAO.deleteBook(bookId)) {
                JOptionPane.showMessageDialog(this, "Deleted book ID: " + bookId);
                loadBooks("");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Delete failed: " + ex.getMessage());
        }
    }

    private void handleUpdatePrice(ActionEvent e) {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a row first"); return; }
        int bookId = (int) model.getValueAt(row, 0);
        try {
            double price = Double.parseDouble(priceUpdateField.getText().trim());
            if (bookDAO.updatePrice(bookId, price)) {
                JOptionPane.showMessageDialog(this, "Price updated");
                loadBooks("");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Update failed: " + ex.getMessage());
        }
    }

    private void showPurchasesDialog() {
        JDialog dialog = new JDialog(this, "Recent Purchases", true);
        dialog.setSize(900, 450);
        dialog.setLocationRelativeTo(this);
        String[] cols = {"Purchase ID","User","Book","Price","Purchased At"};
        DefaultTableModel tm = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r,int c){return false;} };
        JTable t = new JTable(tm);
        UIUtils.applyTableStyles(t);
        try {
            java.util.List<com.library.model.PurchaseRecord> list = purchaseDAO.listPurchases(500);
            for (com.library.model.PurchaseRecord r : list) {
                String user = r.getFullName() + " (" + r.getUsername() + ")";
                tm.addRow(new Object[]{r.getPurchaseId(), user, r.getTitle(), String.format("%.2f", r.getPrice()), r.getPurchaseDate()});
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Failed to load purchases: " + ex.getMessage());
        }
        dialog.setContentPane(new JScrollPane(t));
        dialog.setVisible(true);
    }

    private void showBorrowsDialog() {
        JDialog dialog = new JDialog(this, "Recent Borrows", true);
        dialog.setSize(1000, 500);
        dialog.setLocationRelativeTo(this);
        String[] cols = {"Borrow ID","User","Book","Borrow Date","Due Date","Return Date","Status","Overdue Days"};
        DefaultTableModel tm = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r,int c){return false;} };
        JTable t = new JTable(tm);
        UIUtils.applyTableStyles(t);
        try {
            java.util.List<com.library.model.BorrowAdminRecord> list = borrowDAO.listBorrows(500);
            for (com.library.model.BorrowAdminRecord r : list) {
                String user = r.getFullName() + " (" + r.getUsername() + ")";
                tm.addRow(new Object[]{r.getBorrowId(), user, r.getTitle(), r.getBorrowDate(), r.getDueDate(), r.getReturnDate(), r.getStatus(), r.getOverdueDays()});
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Failed to load borrows: " + ex.getMessage());
        }
        dialog.setContentPane(new JScrollPane(t));
        dialog.setVisible(true);
    }
}
