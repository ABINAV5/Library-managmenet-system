package com.library.gui;

import com.library.util.UIUtils;
import javax.swing.*;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {}
        UIUtils.initTheme();
        SwingUtilities.invokeLater(() -> new AuthFrame().setVisible(true));
    }
}
