package com.library.gui;

import com.library.dao.BookDAO;
import com.library.dao.BorrowDAO;
import com.library.dao.PurchaseDAO;
import com.library.model.Book;
import com.library.model.User;
import com.library.util.UIUtils;
import com.library.gui.AuthFrame;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class UserDashboard extends JFrame {
    private final User user;
    private final BookDAO bookDAO = new BookDAO();
    private final BorrowDAO borrowDAO = new BorrowDAO();
    private final PurchaseDAO purchaseDAO = new PurchaseDAO();

    private JTable table;
    private DefaultTableModel model;
    private JComboBox<Integer> durationBox;
    private JTextField searchField;

    public UserDashboard(User user) {
        this.user = user;
        setTitle("Welcome, " + user.getFullName());
        setSize(900, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel header = UIUtils.makeHeaderPanel("Browse & Borrow", "Search, borrow, or purchase books");

        JPanel topPanel = new JPanel();
        searchField = new JTextField(30);
        JButton searchBtn = new JButton("Search");
        UIUtils.styleSecondary(searchBtn);
        searchBtn.addActionListener(e -> loadBooks(searchField.getText().trim()));
        JButton refreshBtn = new JButton("Refresh");
        UIUtils.styleSecondary(refreshBtn);
        refreshBtn.addActionListener(e -> loadBooks(""));
        JButton myBorrowsBtn = new JButton("My Borrowed Books");
        myBorrowsBtn.addActionListener(e -> showBorrowedDialog());
        topPanel.add(new JLabel("Search:"));
        topPanel.add(searchField);
        topPanel.add(searchBtn);
        topPanel.add(refreshBtn);
        topPanel.add(myBorrowsBtn);
        JButton logoutBtn = new JButton("Logout");
        UIUtils.styleDanger(logoutBtn);
        logoutBtn.addActionListener(e -> {
            this.dispose();
            SwingUtilities.invokeLater(() -> new AuthFrame().setVisible(true));
        });
        topPanel.add(logoutBtn);

        model = new DefaultTableModel(new Object[]{"ID","Title","Author","Category","Available"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        UIUtils.applyTableStyles(table);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel bottom = new JPanel();
        durationBox = new JComboBox<>(new Integer[]{10, 20, 30});
        JButton borrowBtn = new JButton("Borrow Selected");
        UIUtils.stylePrimary(borrowBtn);
        borrowBtn.addActionListener(e -> borrowSelected());
        JButton buyBtn = new JButton("Purchase Selected");
        UIUtils.styleSuccess(buyBtn);
        buyBtn.addActionListener(e -> purchaseSelected());
        bottom.add(new JLabel("Duration (days):"));
        bottom.add(durationBox);
        bottom.add(borrowBtn);
        bottom.add(buyBtn);

        JPanel northContainer = new JPanel(new BorderLayout());
        northContainer.add(header, BorderLayout.NORTH);
        northContainer.add(topPanel, BorderLayout.CENTER);
        add(northContainer, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        loadBooks("");
    }

    private void showBorrowedDialog() {
        JDialog dialog = new JDialog(this, "My Borrowed Books", true);
        dialog.setSize(800, 400);
        dialog.setLocationRelativeTo(this);
        JPanel container = new JPanel(new BorderLayout());
        JLabel countLabel = new JLabel("Loading...");
        countLabel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        container.add(countLabel, BorderLayout.NORTH);
        String[] cols = {"Title","Borrow Date","Due Date","Days Held","Overdue Days","Penalty (Rs)","Status"};
        javax.swing.table.DefaultTableModel tm = new javax.swing.table.DefaultTableModel(cols, 0) { public boolean isCellEditable(int r,int c){return false;} };
        JTable t = new JTable(tm);
        UIUtils.applyTableStyles(t);
        container.add(new JScrollPane(t), BorderLayout.CENTER);
        try {
            java.util.List<com.library.model.BorrowStatus> list = borrowDAO.getActiveBorrowsByUser(user.getUserId());
            countLabel.setText("Currently borrowed: " + list.size());
            for (com.library.model.BorrowStatus s : list) {
                tm.addRow(new Object[]{
                    s.getTitle(),
                    s.getBorrowDate(),
                    s.getDueDate(),
                    s.getDaysHeld(),
                    s.getDaysOverdue(),
                    String.format("%.2f", s.getPenaltyAmount()),
                    s.getStatus()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Failed to load borrows: " + ex.getMessage());
        }
        dialog.setContentPane(container);
        dialog.setVisible(true);
    }

    private void loadBooks(String keyword) {
        try {
            model.setRowCount(0);
            List<Book> books = keyword == null || keyword.isEmpty() ? bookDAO.getAllBooks() : bookDAO.searchBooks(keyword);
            for (Book b : books) {
                model.addRow(new Object[]{b.getBookId(), b.getTitle(), b.getAuthor(), b.getCategory(), b.getAvailableQuantity()});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading books: " + ex.getMessage());
        }
    }

    private void borrowSelected() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a book"); return; }
        int bookId = (int) model.getValueAt(row, 0);
        int available = (int) model.getValueAt(row, 4);
        if (available <= 0) { JOptionPane.showMessageDialog(this, "Book not available"); return; }
        int duration = (Integer) durationBox.getSelectedItem();
        try {
            int borrowId = borrowDAO.borrowBook(user.getUserId(), bookId, duration);
            JOptionPane.showMessageDialog(this, "Borrowed! ID: " + borrowId);
            loadBooks("");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Borrow failed: " + ex.getMessage());
        }
    }

    private void purchaseSelected() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a book"); return; }
        int bookId = (int) model.getValueAt(row, 0);
        try {
            Book b = bookDAO.getById(bookId);
            if (b == null) { JOptionPane.showMessageDialog(this, "Book not found"); return; }
            if (b.getAvailableQuantity() <= 0) { JOptionPane.showMessageDialog(this, "Out of stock"); return; }
            int res = JOptionPane.showConfirmDialog(this,
                    "Purchase '" + b.getTitle() + "' for Rs " + String.format("%.2f", b.getPrice()) + "?",
                    "Confirm Purchase",
                    JOptionPane.YES_NO_OPTION);
            if (res == JOptionPane.YES_OPTION) {
                int pid = purchaseDAO.purchaseBook(user.getUserId(), bookId);
                JOptionPane.showMessageDialog(this, "Purchased successfully. Order #" + pid);
                loadBooks("");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Purchase failed: " + ex.getMessage());
        }
    }
}
