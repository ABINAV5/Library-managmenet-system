package com.library.util;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class UIUtils {
    private static final Color PRIMARY = new Color(33, 150, 243);
    private static final Color SUCCESS = new Color(76, 175, 80);
    private static final Color DANGER = new Color(244, 67, 54);
    private static final Color SECONDARY = new Color(120, 120, 120);
    private static final Color ROW_ALT = new Color(245, 248, 250);

    public static void initTheme() {
        // Global font
        setGlobalFont(new Font("Segoe UI", Font.PLAIN, 14));
        // Table defaults
        UIManager.put("Table.showGrid", Boolean.TRUE);
        UIManager.put("Table.gridColor", new Color(230, 230, 230));
        UIManager.put("Table.selectionBackground", new Color(209, 232, 255));
        UIManager.put("Table.selectionForeground", Color.BLACK);
    }

    public static void setGlobalFont(Font f) {
        java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof Font) {
                UIManager.put(key, f);
            }
        }
    }

    public static void stylePrimary(JButton b) { styleButton(b, PRIMARY); }
    public static void styleSuccess(JButton b) { styleButton(b, SUCCESS); }
    public static void styleDanger(JButton b) { styleButton(b, DANGER); }
    public static void styleSecondary(JButton b) { styleButton(b, SECONDARY); }

    public static void styleButton(JButton b, Color bg) {
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(true);
        b.setBorder(new EmptyBorder(8, 14, 8, 14));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    public static void applyTableStyles(JTable table) {
        table.setRowHeight(26);
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JTableHeader header = table.getTableHeader();
        if (header != null) {
            header.setFont(header.getFont().deriveFont(Font.BOLD));
            header.setBackground(new Color(245, 245, 245));
        }
        DefaultTableCellRenderer renderer = new StripedTableCellRenderer();
        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
    }

    public static JPanel makeHeaderPanel(String title, String subtitle) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(250, 250, 250));
        p.setBorder(new EmptyBorder(12, 16, 12, 16));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        JLabel sub = new JLabel(subtitle);
        sub.setForeground(new Color(110, 110, 110));
        JPanel inner = new JPanel();
        inner.setOpaque(false);
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));
        inner.add(t);
        inner.add(Box.createVerticalStrut(4));
        inner.add(sub);
        p.add(inner, BorderLayout.WEST);
        return p;
    }

    private static class StripedTableCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (!isSelected) {
                c.setBackground(row % 2 == 0 ? Color.WHITE : ROW_ALT);
            }
            return c;
        }
    }
}
