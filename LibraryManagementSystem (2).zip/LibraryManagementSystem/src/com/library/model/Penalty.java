package com.library.model;

public class Penalty {
    private int penaltyId;
    private int borrowId;
    private int userId;
    private int daysOverdue;
    private double penaltyAmount;
    private boolean paid;

    public Penalty() {}

    public Penalty(int penaltyId, int borrowId, int userId, int daysOverdue, double penaltyAmount, boolean paid) {
        this.penaltyId = penaltyId;
        this.borrowId = borrowId;
        this.userId = userId;
        this.daysOverdue = daysOverdue;
        this.penaltyAmount = penaltyAmount;
        this.paid = paid;
    }

    public int getPenaltyId() { return penaltyId; }
    public void setPenaltyId(int penaltyId) { this.penaltyId = penaltyId; }
    public int getBorrowId() { return borrowId; }
    public void setBorrowId(int borrowId) { this.borrowId = borrowId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public int getDaysOverdue() { return daysOverdue; }
    public void setDaysOverdue(int daysOverdue) { this.daysOverdue = daysOverdue; }
    public double getPenaltyAmount() { return penaltyAmount; }
    public void setPenaltyAmount(double penaltyAmount) { this.penaltyAmount = penaltyAmount; }
    public boolean isPaid() { return paid; }
    public void setPaid(boolean paid) { this.paid = paid; }
}
