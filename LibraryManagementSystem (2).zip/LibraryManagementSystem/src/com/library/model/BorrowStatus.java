package com.library.model;

import java.time.LocalDate;

public class BorrowStatus {
    private int borrowId;
    private int bookId;
    private String title;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private int daysHeld;
    private int daysOverdue;
    private double penaltyAmount;
    private String status; // BORROWED/OVERDUE

    public int getBorrowId() { return borrowId; }
    public void setBorrowId(int borrowId) { this.borrowId = borrowId; }
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public LocalDate getBorrowDate() { return borrowDate; }
    public void setBorrowDate(LocalDate borrowDate) { this.borrowDate = borrowDate; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public int getDaysHeld() { return daysHeld; }
    public void setDaysHeld(int daysHeld) { this.daysHeld = daysHeld; }
    public int getDaysOverdue() { return daysOverdue; }
    public void setDaysOverdue(int daysOverdue) { this.daysOverdue = daysOverdue; }
    public double getPenaltyAmount() { return penaltyAmount; }
    public void setPenaltyAmount(double penaltyAmount) { this.penaltyAmount = penaltyAmount; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
